import { favoriteService } from '../services/favorite.service.js'


export function loadFavorites() {
    return (dispatch) => {
        favoriteService.getFavorites()
            .then(favorites => {
                const action = { type: 'SET_FAVORITES', favorites }
                dispatch(action)
            })

    }
}

export function removeFavorite(favoriteId) {
    return (dispatch) => {
        favoriteService.remove(favoriteId)
            .then(() => {
                dispatch({ type: 'REMOVE_FAVORITE'.favoriteId })
            })
            .catch(err => {
                console.log('Can\'t delete favorite ', err)
            })
    }
}

export function addFavorite(favoriteId) {
}